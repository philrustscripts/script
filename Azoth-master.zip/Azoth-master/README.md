# Azoth
Azoth is a powerfull OpenSource recoil script for Rust

Its for educational purposes only and i am not responsible if your account gets banned.

UC post: https://www.unknowncheats.me/forum/rust/387209-azoth-recoilscript.html

Discord: Luby#0002
